/*
 * ParkGrid — Smart Parking System (Premium Edition)
 * -----------------------------------------------------
 * A production-style vehicle slot detection and monitoring
 * system for ESP32, with:
 *
 *  - Debounced ultrasonic readings per slot (noise resistant)
 *  - REST JSON API (/status, /health, /config) with CORS
 *  - Optional MQTT publishing for cloud / home-automation integration
 *  - NTP-synced timestamps on every reading
 *  - Per-slot LED indicators + full-lot buzzer alert
 *  - Optional OLED live status display
 *  - Built-in fallback dashboard (used if web_dashboard/ isn't hosted separately)
 *
 * Author: (Your Name)
 * License: MIT
 */

#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include <time.h>
#include "config.h"

#if MQTT_ENABLED
  #include <PubSubClient.h>
  WiFiClient mqttNetClient;
  PubSubClient mqttClient(mqttNetClient);
  unsigned long lastMqttPublish = 0;
#endif

#if OLED_ENABLED
  #include <Wire.h>
  #include <Adafruit_GFX.h>
  #include <Adafruit_SSD1306.h>
  Adafruit_SSD1306 display(OLED_WIDTH, OLED_HEIGHT, &Wire, OLED_RESET);
#endif

WebServer server(WEB_SERVER_PORT);

bool slotOccupied[NUM_SLOTS];
long slotDistance[NUM_SLOTS];
int debounceCounter[NUM_SLOTS];   // consecutive readings agreeing with pending state
bool pendingState[NUM_SLOTS];

unsigned long lastReadTime = 0;
unsigned long bootTime = 0;
unsigned long totalReadings = 0;
unsigned long failedReadings = 0;

// ---------------------------------------------------------------
// Setup
// ---------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\n=== ParkGrid Premium — booting ===");

  for (int i = 0; i < NUM_SLOTS; i++) {
    pinMode(trigPins[i], OUTPUT);
    pinMode(echoPins[i], INPUT);
    digitalWrite(trigPins[i], LOW);

    if (redLedPins[i] != -1)   pinMode(redLedPins[i], OUTPUT);
    if (greenLedPins[i] != -1) pinMode(greenLedPins[i], OUTPUT);

    slotOccupied[i] = false;
    pendingState[i] = false;
    debounceCounter[i] = 0;
  }

  if (BUZZER_PIN != -1) pinMode(BUZZER_PIN, OUTPUT);

  #if OLED_ENABLED
    if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
      Serial.println("OLED init failed (continuing without display)");
    } else {
      display.clearDisplay();
      display.setTextSize(1);
      display.setTextColor(SSD1306_WHITE);
      display.setCursor(0, 0);
      display.println("ParkGrid Premium");
      display.println("Booting...");
      display.display();
    }
  #endif

  connectToWiFi();

  #if NTP_ENABLED
    configTime(GMT_OFFSET_SEC, DAYLIGHT_OFFSET_SEC, NTP_SERVER);
  #endif

  #if MQTT_ENABLED
    mqttClient.setServer(MQTT_BROKER, MQTT_PORT);
  #endif

  setupWebServer();
  bootTime = millis();
  Serial.println("=== Setup complete ===");
}

// ---------------------------------------------------------------
// Main Loop
// ---------------------------------------------------------------
void loop() {
  server.handleClient();

  #if MQTT_ENABLED
    maintainMqttConnection();
  #endif

  if (millis() - lastReadTime >= SENSOR_READ_INTERVAL_MS) {
    lastReadTime = millis();
    readAllSlotsDebounced();
    updateIndicators();
    updateOLED();
    checkLotFullAlert();
    printStatusToSerial();

    #if MQTT_ENABLED
      maybePublishMqtt();
    #endif
  }
}

// ---------------------------------------------------------------
// WiFi Connection
// ---------------------------------------------------------------
void connectToWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.setHostname(DEVICE_NAME);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to WiFi");

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < WIFI_MAX_ATTEMPTS) {
    delay(WIFI_RETRY_MS);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nConnected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nFailed to connect to WiFi. Check credentials in config.h.");
  }
}

// ---------------------------------------------------------------
// Read distance from a single ultrasonic sensor (in cm)
// ---------------------------------------------------------------
long readDistanceCM(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH, 30000); // 30ms timeout (~5m max range)
  if (duration == 0) return -1; // no echo received

  return duration * 0.0343 / 2;
}

// ---------------------------------------------------------------
// Read all slots with debouncing to avoid sensor-noise flapping.
// A slot only flips state after DEBOUNCE_SAMPLES consecutive
// readings agree with the new state.
// ---------------------------------------------------------------
void readAllSlotsDebounced() {
  for (int i = 0; i < NUM_SLOTS; i++) {
    long d = readDistanceCM(trigPins[i], echoPins[i]);
    totalReadings++;

    if (d < 0) {
      failedReadings++;
      continue; // keep last known good state on a failed reading
    }

    slotDistance[i] = d;
    bool rawOccupied = (d < SLOT_THRESHOLD_CM);

    if (rawOccupied == pendingState[i]) {
      debounceCounter[i]++;
    } else {
      pendingState[i] = rawOccupied;
      debounceCounter[i] = 1;
    }

    if (debounceCounter[i] >= DEBOUNCE_SAMPLES) {
      slotOccupied[i] = pendingState[i];
    }
  }
}

// ---------------------------------------------------------------
// Update LED indicators per slot
// ---------------------------------------------------------------
void updateIndicators() {
  for (int i = 0; i < NUM_SLOTS; i++) {
    if (redLedPins[i] != -1)   digitalWrite(redLedPins[i], slotOccupied[i] ? HIGH : LOW);
    if (greenLedPins[i] != -1) digitalWrite(greenLedPins[i], slotOccupied[i] ? LOW : HIGH);
  }
}

// ---------------------------------------------------------------
// Sound buzzer briefly if all slots are occupied
// ---------------------------------------------------------------
void checkLotFullAlert() {
  if (BUZZER_PIN == -1 || !FULL_LOT_ALERT_ENABLED) return;

  bool full = true;
  for (int i = 0; i < NUM_SLOTS; i++) {
    if (!slotOccupied[i]) { full = false; break; }
  }

  if (full) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(200);
    digitalWrite(BUZZER_PIN, LOW);

    #if MQTT_ENABLED
      if (mqttClient.connected()) {
        mqttClient.publish(MQTT_TOPIC_ALERT, "lot_full");
      }
    #endif
  }
}

// ---------------------------------------------------------------
// Update OLED display with current slot statuses
// ---------------------------------------------------------------
void updateOLED() {
  #if OLED_ENABLED
    display.clearDisplay();
    display.setTextSize(1);
    display.setCursor(0, 0);
    display.println(LOT_LABEL);
    display.drawLine(0, 9, OLED_WIDTH, 9, SSD1306_WHITE);

    int occupied = 0;
    for (int i = 0; i < NUM_SLOTS; i++) if (slotOccupied[i]) occupied++;

    display.setCursor(0, 13);
    display.print("Occupied: ");
    display.print(occupied);
    display.print("/");
    display.println(NUM_SLOTS);

    // Show up to 4 slot lines to fit a 64px display
    int maxLines = min(NUM_SLOTS, 4);
    for (int i = 0; i < maxLines; i++) {
      display.setCursor(0, 24 + (i * 10));
      display.print("S");
      display.print(i + 1);
      display.print(": ");
      display.println(slotOccupied[i] ? "OCCUPIED" : "FREE");
    }
    display.display();
  #endif
}

// ---------------------------------------------------------------
// Serial debug output
// ---------------------------------------------------------------
void printStatusToSerial() {
  Serial.println("---- Slot Status ----");
  for (int i = 0; i < NUM_SLOTS; i++) {
    Serial.printf("Slot %d: %s (distance: %ld cm)\n",
                  i + 1,
                  slotOccupied[i] ? "OCCUPIED" : "FREE",
                  slotDistance[i]);
  }
}

// ---------------------------------------------------------------
// Timestamp helper (ISO 8601, requires NTP sync)
// ---------------------------------------------------------------
String getTimestamp() {
  #if NTP_ENABLED
    struct tm timeinfo;
    if (getLocalTime(&timeinfo)) {
      char buf[30];
      strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S", &timeinfo);
      return String(buf);
    }
  #endif
  return String(millis());
}

// =================================================================
// MQTT
// =================================================================
#if MQTT_ENABLED

void maintainMqttConnection() {
  if (!mqttClient.connected()) {
    if (mqttClient.connect(MQTT_CLIENT_ID)) {
      Serial.println("MQTT connected.");
    }
  }
  mqttClient.loop();
}

void maybePublishMqtt() {
  if (millis() - lastMqttPublish < MQTT_PUBLISH_INTERVAL_MS) return;
  lastMqttPublish = millis();

  if (!mqttClient.connected()) return;

  String payload = buildStatusJson();
  mqttClient.publish(MQTT_TOPIC_STATUS, payload.c_str());
}

#endif

// =================================================================
// Web Server
// =================================================================
void setupWebServer() {
  server.on("/", HTTP_GET, handleRoot);
  server.on("/status", HTTP_GET, handleStatus);
  server.on("/health", HTTP_GET, handleHealth);
  server.on("/config", HTTP_GET, handleConfigInfo);
  server.onNotFound(handleNotFound);
  server.begin();
  Serial.println("Web server started.");
}

void applyCorsHeaders() {
  #if CORS_ENABLED
    server.sendHeader("Access-Control-Allow-Origin", "*");
  #endif
}

String buildStatusJson() {
  DynamicJsonDocument doc(1024);
  doc["device"] = DEVICE_NAME;
  doc["lot"] = LOT_LABEL;
  doc["timestamp"] = getTimestamp();

  JsonArray slots = doc.createNestedArray("slots");
  int occupiedCount = 0;

  for (int i = 0; i < NUM_SLOTS; i++) {
    JsonObject slot = slots.createNestedObject();
    slot["id"] = i + 1;
    slot["occupied"] = slotOccupied[i];
    slot["distance_cm"] = slotDistance[i];
    if (slotOccupied[i]) occupiedCount++;
  }

  doc["total_slots"] = NUM_SLOTS;
  doc["occupied"] = occupiedCount;
  doc["available"] = NUM_SLOTS - occupiedCount;

  String response;
  serializeJson(doc, response);
  return response;
}

// Lightweight built-in dashboard (fallback if web_dashboard/ isn't hosted separately)
void handleRoot() {
  applyCorsHeaders();
  String html = "<!DOCTYPE html><html><head><title>ParkGrid</title>";
  html += "<meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<meta http-equiv='refresh' content='3'>";
  html += "<style>body{font-family:'Courier New',monospace;text-align:center;background:#0b0d10;color:#e9ebee;}";
  html += "h1{color:#ffb02e;} .slot{display:inline-block;width:120px;margin:8px;padding:18px;border-radius:10px;font-weight:bold;border:1px solid #2a2f38;}";
  html += ".free{background:#1f4d3d;color:#34d399;} .occupied{background:#5c2424;color:#ff5d5d;}</style></head><body>";
  html += "<h1>ParkGrid — " + String(LOT_LABEL) + "</h1>";
  html += "<p>For the full premium dashboard, open web_dashboard/index.html and link this device's IP.</p>";

  for (int i = 0; i < NUM_SLOTS; i++) {
    html += "<div class='slot " + String(slotOccupied[i] ? "occupied" : "free") + "'>";
    html += "Slot " + String(i + 1) + "<br>" + String(slotOccupied[i] ? "OCCUPIED" : "FREE");
    html += "</div>";
  }

  html += "</body></html>";
  server.send(200, "text/html", html);
}

// Main JSON status endpoint consumed by the premium dashboard
void handleStatus() {
  applyCorsHeaders();
  server.send(200, "application/json", buildStatusJson());
}

// Health/diagnostics endpoint
void handleHealth() {
  applyCorsHeaders();
  DynamicJsonDocument doc(512);
  doc["uptime_ms"] = millis() - bootTime;
  doc["wifi_connected"] = (WiFi.status() == WL_CONNECTED);
  doc["wifi_rssi"] = WiFi.RSSI();
  doc["total_readings"] = totalReadings;
  doc["failed_readings"] = failedReadings;
  double successRate = totalReadings > 0
    ? 100.0 * (totalReadings - failedReadings) / totalReadings
    : 100.0;
  doc["sensor_success_rate_pct"] = successRate;

  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

// Returns current config (sans WiFi password) for debugging
void handleConfigInfo() {
  applyCorsHeaders();
  DynamicJsonDocument doc(512);
  doc["device"] = DEVICE_NAME;
  doc["lot"] = LOT_LABEL;
  doc["num_slots"] = NUM_SLOTS;
  doc["threshold_cm"] = SLOT_THRESHOLD_CM;
  doc["debounce_samples"] = DEBOUNCE_SAMPLES;
  doc["mqtt_enabled"] = MQTT_ENABLED;

  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

void handleNotFound() {
  applyCorsHeaders();
  server.send(404, "application/json", "{\"error\":\"not_found\"}");
}
