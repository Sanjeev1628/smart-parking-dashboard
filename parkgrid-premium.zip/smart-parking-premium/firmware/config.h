/*
 * config.h
 * ParkGrid — Smart Parking System (Premium Edition)
 * Central configuration. Edit values below to match your
 * hardware, network, and optional cloud/MQTT integration.
 */

#ifndef CONFIG_H
#define CONFIG_H

// ====================== Identity ======================
#define DEVICE_NAME     "parkgrid-sector-04"
#define LOT_LABEL       "Sector 04 - Level 1"

// ====================== WiFi ======================
#define WIFI_SSID       "YourWiFiName"
#define WIFI_PASSWORD   "YourWiFiPassword"
#define WIFI_RETRY_MS   500
#define WIFI_MAX_ATTEMPTS 40

// ====================== Slots ======================
#define NUM_SLOTS 8   // Total number of parking slots to monitor

// GPIO pins for ultrasonic sensors (TRIG / ECHO) - one pair per slot.
// Extend these arrays if you increase NUM_SLOTS.
const int trigPins[NUM_SLOTS] = {5, 17, 16, 4, 2, 15, 0, 27};
const int echoPins[NUM_SLOTS] = {18, 19, 21, 22, 23, 32, 33, 34};

// Distance threshold (cm). Below this, a slot is OCCUPIED.
#define SLOT_THRESHOLD_CM 10

// Number of consecutive readings required before flipping a slot's
// state — smooths out sensor noise / false triggers.
#define DEBOUNCE_SAMPLES 3

// ====================== Indicators ======================
// One Red + one Green LED per slot. Set to -1 to disable a given LED.
const int redLedPins[NUM_SLOTS]   = {-1, -1, -1, -1, -1, -1, -1, -1};
const int greenLedPins[NUM_SLOTS] = {-1, -1, -1, -1, -1, -1, -1, -1};

#define BUZZER_PIN -1          // set to a GPIO number to enable
#define FULL_LOT_ALERT_ENABLED true

// ====================== OLED Display ======================
#define OLED_ENABLED   true
#define OLED_WIDTH     128
#define OLED_HEIGHT    64
#define OLED_RESET     -1

// ====================== Web Server ======================
#define WEB_SERVER_PORT 80
#define SENSOR_READ_INTERVAL_MS 1500
#define CORS_ENABLED true       // allow dashboard hosted elsewhere (e.g. GitHub Pages) to fetch /status

// ====================== MQTT (optional) ======================
// Leave MQTT_ENABLED false if you only want the local REST API.
#define MQTT_ENABLED        false
#define MQTT_BROKER         "broker.hivemq.com"
#define MQTT_PORT           1883
#define MQTT_CLIENT_ID      DEVICE_NAME
#define MQTT_TOPIC_STATUS   "parkgrid/sector04/status"
#define MQTT_TOPIC_ALERT    "parkgrid/sector04/alert"
#define MQTT_PUBLISH_INTERVAL_MS 5000

// ====================== NTP (for timestamps) ======================
#define NTP_ENABLED       true
#define NTP_SERVER        "pool.ntp.org"
#define GMT_OFFSET_SEC    0
#define DAYLIGHT_OFFSET_SEC 0

#endif
