<div align="center">

# ParkGrid

### Smart Parking Control System — Premium Edition

Real-time vehicle slot detection, a control-room dashboard, and optional cloud access — built on ESP32.

![Platform](https://img.shields.io/badge/platform-ESP32-1b1f26?style=flat-square&labelColor=0b0d10)
![Status](https://img.shields.io/badge/status-active-34d399?style=flat-square&labelColor=0b0d10)
![License](https://img.shields.io/badge/license-MIT-ffb02e?style=flat-square&labelColor=0b0d10)
![Made with](https://img.shields.io/badge/dashboard-vanilla%20JS-1b1f26?style=flat-square&labelColor=0b0d10)

</div>

<br/>

<img src="images/architecture.svg" alt="ParkGrid system architecture diagram" width="100%" />

<br/>

## What this is

ParkGrid turns a handful of ultrasonic sensors and an ESP32 into a real parking-lot monitoring system: every slot's occupancy is detected, debounced against sensor noise, exposed over a JSON API, and rendered on a dark, instrumentation-style dashboard that looks like it belongs in an actual control room — animated boom gate, live occupancy gauge, slot grid, rolling history chart, and operational metrics.

It's designed to be **demoable in 30 seconds** (a built-in "Run demo data" mode simulates live traffic with no hardware attached) and **deployable for real** (debounced readings, an optional MQTT bridge, NTP timestamps, and an optional cloud relay for off-network access).

---

## Highlights

**Hardware-aware firmware** — debounced ultrasonic readings (configurable sample count) prevent a single noisy reading from flapping a slot's state; failed readings are tracked and reported via `/health`.

**A dashboard that doesn't look templated** — dark control-room palette lifted from real garage signage (amber caution, signal green), monospace data type, an animated boom gate that opens when a slot frees up, a live occupancy gauge, and an SVG history sparkline drawn from scratch — no charting library.

**Works with zero hardware** — click *Run demo data* and the dashboard simulates a live lot with slots filling and emptying, so you can show it off before any sensor is wired up.

**Cloud-optional** — a 100-line Node relay (`cloud/server.js`) lets the same dashboard be viewed from anywhere, not just on the ESP32's Wi-Fi network.

**MQTT-ready** — flip one config flag to publish every reading to an MQTT broker for Home Assistant, Node-RED, or any automation pipeline.

---

## Table of Contents

- [Live Demo Mode](#live-demo-mode)
- [System Architecture](#system-architecture)
- [Hardware](#hardware)
- [Firmware Setup](#firmware-setup)
- [Dashboard Setup](#dashboard-setup)
- [Optional Cloud Relay](#optional-cloud-relay)
- [API Reference](#api-reference)
- [Project Structure](#project-structure)
- [Customization](#customization)
- [Roadmap](#roadmap)
- [License](#license)

---

## Live Demo Mode

No ESP32 yet? Open `web_dashboard/index.html` directly in a browser and click **Run demo data**. The dashboard generates a simulated 8-slot lot, with slots randomly filling and emptying every few seconds — the gate animation, occupancy gauge, slot grid, and history chart all respond exactly as they would to a real device. This is the fastest way to see (and screenshot) the full experience.

---

## System Architecture

```
 Ultrasonic Sensors  →  ESP32 (debounce + threshold)  →  REST JSON API (/status)
        (per slot)         │                                   │
                            ├─ OLED + LED + buzzer (on-site)    ├─ Local dashboard (same Wi-Fi)
                            └─ optional MQTT publish            └─ optional Cloud Relay → dashboard anywhere
```

See [`images/architecture.svg`](images/architecture.svg) for the full diagram.

---

## Hardware

| Component                  | Quantity     | Purpose                                |
|-----------------------------|--------------|------------------------------------------|
| ESP32 Dev Board              | 1            | Main controller, Wi-Fi, web server       |
| HC-SR04 Ultrasonic Sensor    | 1 per slot   | Vehicle presence detection               |
| 0.96" OLED Display (I2C)     | 1 (optional) | On-site live status display              |
| Red/Green LEDs               | 2 per slot (optional) | Local visual indicator         |
| Buzzer                       | 1 (optional) | Full-lot audible alert                   |
| 1kΩ + 2kΩ resistors           | 1 pair per sensor | Voltage divider for ECHO pin       |
| 5V/2A Power Supply            | 1            | Stable power for sensors + ESP32         |

Full wiring instructions, including the ECHO voltage divider and OLED I2C pins, are in [`docs/circuit_diagram.md`](docs/circuit_diagram.md).

---

## Firmware Setup

1. Open `firmware/parkgrid_premium.ino` in Arduino IDE (2.0+) or PlatformIO.
2. Install libraries: `WiFi`, `WebServer`, `ArduinoJson`, `Adafruit_SSD1306`, `Adafruit_GFX`, and (only if using MQTT) `PubSubClient`.
3. Edit `firmware/config.h`:
   - Set `WIFI_SSID` / `WIFI_PASSWORD`.
   - Set `NUM_SLOTS` and the matching `trigPins[]` / `echoPins[]` arrays.
   - Optionally enable `MQTT_ENABLED`, set LED pins, or set `BUZZER_PIN`.
4. Select board: **Tools → Board → ESP32 Dev Module**.
5. Upload, then open Serial Monitor at `115200` baud to confirm Wi-Fi connection and note the printed IP address.

---

## Dashboard Setup

The dashboard is fully static (HTML/CSS/JS, no build step) — open `web_dashboard/index.html` directly, or host it anywhere (GitHub Pages, Netlify, a simple static file server).

1. Open the dashboard.
2. Enter the ESP32's IP address (printed in Serial Monitor) into **Device address** and click **Link device**.
3. The dashboard polls `http://<esp32-ip>/status` every 3 seconds and renders live slot states, the occupancy gauge, gate animation, and history chart.

If you're hosting the dashboard on a different origin than the ESP32 (e.g. GitHub Pages calling your home network), make sure `CORS_ENABLED` is `true` in `config.h` (it is by default).

---

## Optional Cloud Relay

To view the dashboard outside your local Wi-Fi network, deploy the small relay in `cloud/`:

```bash
cd cloud
npm install
npm start
```

Then have your ESP32 (or a small script on the same network) `POST` its status to the relay's `/ingest` endpoint, and point the dashboard's **Device address** field at the relay's public URL instead of the ESP32's local IP. Full instructions: [`cloud/README.md`](cloud/README.md).

---

## API Reference

| Endpoint   | Method | Description                                              |
|------------|--------|------------------------------------------------------------|
| `/status`  | GET    | Current slot states, occupied/available counts, timestamp |
| `/health`  | GET    | Uptime, Wi-Fi signal strength, sensor success rate          |
| `/config`  | GET    | Non-sensitive config summary (slot count, threshold, etc.) |

Example `/status` response:

```json
{
  "device": "parkgrid-sector-04",
  "lot": "Sector 04 - Level 1",
  "timestamp": "2026-06-18T14:32:01",
  "slots": [
    { "id": 1, "occupied": true,  "distance_cm": 6 },
    { "id": 2, "occupied": false, "distance_cm": 142 }
  ],
  "total_slots": 8,
  "occupied": 1,
  "available": 7
}
```

---

## Project Structure

```
parkgrid-premium/
├── README.md
├── LICENSE
├── .gitignore
├── firmware/
│   ├── parkgrid_premium.ino     # main ESP32 sketch
│   └── config.h                 # all configuration in one place
├── web_dashboard/
│   ├── index.html
│   ├── style.css                # control-room visual design
│   └── script.js                # polling, gate animation, charts, demo mode
├── cloud/
│   ├── server.js                # optional relay for off-network access
│   ├── package.json
│   └── README.md
├── docs/
│   ├── circuit_diagram.md
│   └── project_report.md
└── images/
    └── architecture.svg
```

---

## Customization

- **Slot count** — change `NUM_SLOTS` in `config.h` and extend the pin arrays; the dashboard adapts automatically to however many slots `/status` reports.
- **Threshold & debounce** — tune `SLOT_THRESHOLD_CM` and `DEBOUNCE_SAMPLES` to match your sensor mounting height and tolerance for noise.
- **Color language** — all dashboard colors are CSS variables at the top of `style.css` (`--amber`, `--green`, `--red`, etc.) — change the palette without touching layout code.
- **Metrics row** — `metric-dwell`, `metric-turnover`, `metric-peak`, and `metric-uptime` are currently derived client-side for demo richness; wire them to real server-side aggregation (e.g. in the cloud relay) for production use.

---

## Roadmap

- [ ] Persistent historical storage (SQLite/Postgres) in the cloud relay for real analytics
- [ ] ESP32-CAM integration for license plate capture on entry/exit
- [ ] Servo-controlled physical gate, driven by the same `/status` logic
- [ ] Native mobile app (push notifications when a slot frees up)
- [ ] Multi-lot support — one dashboard, many ParkGrid devices
- [ ] Slot reservation + payment integration

---

## License

MIT — see [LICENSE](LICENSE).

---

<div align="center">
<sub>Part of an IoT systems portfolio — alongside IoT Weather Station, Smart Irrigation System, Smart Home Automation, and Fire Detection System.</sub>
</div>
