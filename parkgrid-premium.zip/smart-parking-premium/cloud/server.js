/**
 * ParkGrid Cloud Relay
 * ---------------------------------------------------------
 * Optional lightweight relay server so the dashboard can be
 * viewed outside the ESP32's local network (e.g. hosted on
 * Render, Railway, Fly.io, or a Raspberry Pi).
 *
 * The ESP32 (or a script on the same LAN) pushes status to
 * this relay via POST /ingest, and any client anywhere can
 * read the latest status via GET /status.
 *
 * Usage:
 *   npm install
 *   node server.js
 *
 * Then point the dashboard's "Device address" field at this
 * relay's URL instead of the ESP32's local IP.
 */

const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

let latestStatus = {
  device: null,
  lot: null,
  timestamp: null,
  slots: [],
  total_slots: 0,
  occupied: 0,
  available: 0,
};

let history = []; // rolling buffer of recent snapshots
const MAX_HISTORY = 200;

// Simple shared-secret check so randoms can't spam your relay.
// Set RELAY_SECRET as an environment variable in production.
const RELAY_SECRET = process.env.RELAY_SECRET || null;

function checkAuth(req, res, next) {
  if (!RELAY_SECRET) return next(); // no secret configured, allow all
  const provided = req.headers['x-relay-secret'];
  if (provided !== RELAY_SECRET) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}

// ESP32 (or any device on the LAN) pushes its latest reading here
app.post('/ingest', checkAuth, (req, res) => {
  const body = req.body;
  if (!body || !Array.isArray(body.slots)) {
    return res.status(400).json({ error: 'invalid_payload' });
  }

  latestStatus = {
    device: body.device || 'unknown',
    lot: body.lot || 'unknown',
    timestamp: body.timestamp || new Date().toISOString(),
    slots: body.slots,
    total_slots: body.total_slots ?? body.slots.length,
    occupied: body.occupied ?? body.slots.filter((s) => s.occupied).length,
    available: body.available ?? body.slots.filter((s) => !s.occupied).length,
  };

  history.push(latestStatus);
  if (history.length > MAX_HISTORY) history.shift();

  res.json({ ok: true });
});

// Dashboard (or anyone) reads the latest snapshot
app.get('/status', (req, res) => {
  res.json(latestStatus);
});

// Rolling history, useful for analytics or longer charts
app.get('/history', (req, res) => {
  res.json({ count: history.length, history });
});

app.get('/', (req, res) => {
  res.json({ service: 'ParkGrid Cloud Relay', status: 'running' });
});

app.listen(PORT, () => {
  console.log(`ParkGrid relay listening on port ${PORT}`);
});
