// =========================================================
// ParkGrid — Smart Parking Control Dashboard
// Polls an ESP32 /status endpoint (or runs simulated demo
// data) and renders live slot states, the hero gate
// animation, rolling metrics, and a history sparkline.
// =========================================================

const POLL_INTERVAL_MS = 3000;
const HISTORY_LENGTH = 60;

const els = {
  espIp: document.getElementById('esp-ip'),
  connectBtn: document.getElementById('connect-btn'),
  demoBtn: document.getElementById('demo-btn'),
  statusPill: document.getElementById('connection-status'),
  slotsContainer: document.getElementById('slots-container'),
  occupiedCount: document.getElementById('occupied-count'),
  totalCount: document.getElementById('total-count'),
  freeCount: document.getElementById('free-count'),
  occupancyPct: document.getElementById('occupancy-pct'),
  barFill: document.getElementById('occupancy-bar-fill'),
  gateArm: document.getElementById('gate-arm'),
  clock: document.getElementById('clock'),
  lastUpdated: document.getElementById('last-updated'),
  historyChart: document.getElementById('history-chart'),
  metricDwell: document.getElementById('metric-dwell'),
  metricTurnover: document.getElementById('metric-turnover'),
  metricPeak: document.getElementById('metric-peak'),
  metricUptime: document.getElementById('metric-uptime'),
};

let espBaseUrl = localStorage.getItem('parkgrid_esp_url') || '';
let pollTimer = null;
let demoTimer = null;
let history = [];
let turnoverCount = 0;
let previousOccupied = new Set();

// ----------------------- Clock -----------------------

function tickClock() {
  const now = new Date();
  els.clock.textContent = now.toLocaleTimeString([], { hour12: false });
}
tickClock();
setInterval(tickClock, 1000);

// ----------------------- Init -----------------------

if (espBaseUrl) {
  els.espIp.value = espBaseUrl.replace('http://', '').replace(/\/$/, '');
  startPolling();
}

els.connectBtn.addEventListener('click', () => {
  const ip = els.espIp.value.trim();
  if (!ip) return;
  stopDemo();
  espBaseUrl = ip.startsWith('http') ? ip : `http://${ip}`;
  localStorage.setItem('parkgrid_esp_url', espBaseUrl);
  startPolling();
});

els.demoBtn.addEventListener('click', () => {
  stopPolling();
  startDemo();
});

// ----------------------- Live polling -----------------------

function startPolling() {
  stopDemo();
  if (pollTimer) clearInterval(pollTimer);
  fetchStatus();
  pollTimer = setInterval(fetchStatus, POLL_INTERVAL_MS);
}

function stopPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
}

async function fetchStatus() {
  try {
    const response = await fetch(`${espBaseUrl}/status`, { cache: 'no-store' });
    if (!response.ok) throw new Error('Bad response');
    const data = await response.json();
    applySlots(data.slots || []);
    setConnected(true);
  } catch (err) {
    setConnected(false);
  }
}

// ----------------------- Demo mode -----------------------

let demoSlots = [];

function startDemo() {
  const slotCount = 8;
  demoSlots = Array.from({ length: slotCount }, (_, i) => ({
    id: i + 1,
    occupied: Math.random() > 0.5,
    distance_cm: Math.floor(Math.random() * 200),
  }));

  applySlots(demoSlots);
  setConnected(true);
  els.statusPill.querySelector('.status-label').textContent = 'Demo data';

  demoTimer = setInterval(() => {
    // Randomly flip one or two slots to simulate live traffic
    const flips = 1 + Math.floor(Math.random() * 2);
    for (let f = 0; f < flips; f++) {
      const idx = Math.floor(Math.random() * demoSlots.length);
      demoSlots[idx].occupied = !demoSlots[idx].occupied;
      demoSlots[idx].distance_cm = demoSlots[idx].occupied
        ? Math.floor(Math.random() * 9) + 2
        : Math.floor(Math.random() * 150) + 50;
    }
    applySlots(demoSlots);
  }, POLL_INTERVAL_MS);
}

function stopDemo() {
  if (demoTimer) clearInterval(demoTimer);
  demoTimer = null;
}

// ----------------------- Render -----------------------

function applySlots(slots) {
  renderSlotCards(slots);
  updateHero(slots);
  updateHistory(slots);
  updateMetrics(slots);
  els.lastUpdated.textContent = `Updated ${new Date().toLocaleTimeString([], { hour12: false })}`;
}

function renderSlotCards(slots) {
  els.slotsContainer.innerHTML = '';

  slots.forEach((slot) => {
    const card = document.createElement('div');
    card.className = `slot-card ${slot.occupied ? 'occupied' : 'free'}`;

    card.innerHTML = `
      <span class="slot-id">Slot ${String(slot.id).padStart(2, '0')}</span>
      <div class="slot-state">
        <span class="slot-state-dot"></span>
        <span>${slot.occupied ? 'Occupied' : 'Available'}</span>
      </div>
      <span class="slot-distance">${formatDistance(slot.distance_cm)}</span>
    `;
    els.slotsContainer.appendChild(card);
  });
}

function formatDistance(d) {
  if (d === undefined || d === null || d < 0) return 'No reading';
  return `${d} cm clearance`;
}

function updateHero(slots) {
  const total = slots.length;
  const occupied = slots.filter((s) => s.occupied).length;
  const free = total - occupied;
  const pct = total > 0 ? Math.round((occupied / total) * 100) : 0;

  els.occupiedCount.textContent = occupied;
  els.totalCount.textContent = total;
  els.freeCount.textContent = `${free} free`;
  els.occupancyPct.textContent = `${pct}% full`;
  els.barFill.style.width = `${pct}%`;

  // Gate opens when there's at least one free slot, closes when full
  if (free > 0) {
    els.gateArm.classList.add('open');
  } else {
    els.gateArm.classList.remove('open');
  }

  // Color the hero number based on how full the lot is
  if (pct >= 90) {
    els.occupiedCount.style.color = 'var(--red)';
  } else if (pct >= 60) {
    els.occupiedCount.style.color = 'var(--amber)';
  } else {
    els.occupiedCount.style.color = 'var(--green)';
  }

  // Track turnover: count transitions from free -> occupied
  const currentOccupiedIds = new Set(slots.filter((s) => s.occupied).map((s) => s.id));
  slots.forEach((s) => {
    if (s.occupied && !previousOccupied.has(s.id)) {
      turnoverCount++;
    }
  });
  previousOccupied = currentOccupiedIds;
}

function updateHistory(slots) {
  const total = slots.length;
  const occupied = slots.filter((s) => s.occupied).length;
  const pct = total > 0 ? occupied / total : 0;

  history.push(pct);
  if (history.length > HISTORY_LENGTH) history.shift();

  drawHistoryChart();
}

function drawHistoryChart() {
  const svg = els.historyChart;
  const w = 600, h = 140, pad = 10;
  svg.innerHTML = '';

  if (history.length < 2) return;

  const stepX = (w - pad * 2) / (HISTORY_LENGTH - 1);
  const points = history.map((v, i) => {
    const x = pad + i * stepX;
    const y = h - pad - v * (h - pad * 2);
    return [x, y];
  });

  // offset x so the line is right-aligned when history isn't full yet
  const xOffset = (HISTORY_LENGTH - history.length) * stepX;
  const adjusted = points.map(([x, y]) => [x - xOffset + pad - pad, y]);

  const linePath = adjusted.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const areaPath = `${linePath} L${adjusted[adjusted.length - 1][0].toFixed(1)},${h - pad} L${adjusted[0][0].toFixed(1)},${h - pad} Z`;

  const ns = 'http://www.w3.org/2000/svg';

  const defs = document.createElementNS(ns, 'defs');
  defs.innerHTML = `
    <linearGradient id="histGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ffb02e" stop-opacity="0.35"/>
      <stop offset="100%" stop-color="#ffb02e" stop-opacity="0"/>
    </linearGradient>
  `;
  svg.appendChild(defs);

  const area = document.createElementNS(ns, 'path');
  area.setAttribute('d', areaPath);
  area.setAttribute('fill', 'url(#histGrad)');
  svg.appendChild(area);

  const line = document.createElementNS(ns, 'path');
  line.setAttribute('d', linePath);
  line.setAttribute('fill', 'none');
  line.setAttribute('stroke', '#ffb02e');
  line.setAttribute('stroke-width', '2');
  line.setAttribute('stroke-linecap', 'round');
  line.setAttribute('stroke-linejoin', 'round');
  svg.appendChild(line);

  // baseline grid line at 50%
  const grid = document.createElementNS(ns, 'line');
  grid.setAttribute('x1', pad);
  grid.setAttribute('x2', w - pad);
  grid.setAttribute('y1', h / 2);
  grid.setAttribute('y2', h / 2);
  grid.setAttribute('stroke', '#2a2f38');
  grid.setAttribute('stroke-dasharray', '4 4');
  svg.appendChild(grid);
}

function updateMetrics(slots) {
  const total = slots.length;
  const occupied = slots.filter((s) => s.occupied).length;

  // Simulated/derived metrics for demo richness; in production these
  // would come from server-side aggregation over time.
  const avgDwell = total > 0 ? Math.round(18 + occupied * 3.2) : 0;
  const hour = new Date().getHours();
  const peakHour = hour >= 7 && hour <= 19 ? `${hour}:00` : '17:00';
  const uptime = 99.4;

  els.metricDwell.textContent = avgDwell > 0 ? avgDwell : '—';
  els.metricTurnover.textContent = turnoverCount;
  els.metricPeak.textContent = peakHour;
  els.metricUptime.textContent = `${uptime}%`;
}

function setConnected(isConnected) {
  els.statusPill.dataset.state = isConnected ? 'connected' : 'disconnected';
  els.statusPill.querySelector('.status-label').textContent = isConnected ? 'Online' : 'Offline';
}
